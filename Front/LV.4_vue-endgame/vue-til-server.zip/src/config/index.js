export const SECRET_KEY = 'vuex-with-token';
export const EXPIRATION_DATE = '100d';
