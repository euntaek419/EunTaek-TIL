export default {
  timestamps: {
    createdAt: 'created_at',
  },
};
